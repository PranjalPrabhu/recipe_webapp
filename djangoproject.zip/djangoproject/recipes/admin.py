from django.contrib import admin   #type:ignore
from . import models

admin.site.register(models.Recipe)
# Register your models here.
